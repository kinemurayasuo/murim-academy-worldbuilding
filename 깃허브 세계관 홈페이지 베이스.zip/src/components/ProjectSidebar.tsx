import { Button } from "./ui/button";
import { Plus, Folder, Trash2 } from "lucide-react";
import { cn } from "./ui/utils";

interface Project {
  id: string;
  name: string;
  description: string;
  color: string;
}

interface ProjectSidebarProps {
  projects: Project[];
  selectedProjectId: string | null;
  onSelectProject: (projectId: string) => void;
  onAddProject: () => void;
  onDeleteProject?: (projectId: string) => void;
  isAdminMode?: boolean;
}

export function ProjectSidebar({
  projects,
  selectedProjectId,
  onSelectProject,
  onAddProject,
  onDeleteProject,
  isAdminMode = false,
}: ProjectSidebarProps) {
  return (
    <div className="w-64 bg-white border-r border-gray-200 h-full flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h2 className="mb-3">세계관 프로젝트</h2>
        <Button
          onClick={onAddProject}
          className="w-full"
          size="sm"
        >
          <Plus className="w-4 h-4 mr-2" />
          새 프로젝트
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {projects.map((project) => (
            <div key={project.id} className="relative group">
              <button
                onClick={() => onSelectProject(project.id)}
                className={cn(
                  "w-full flex items-center gap-3 p-3 rounded-lg transition-all text-left hover:bg-gray-50",
                  selectedProjectId === project.id
                    ? "bg-blue-50 border border-blue-200"
                    : "border border-transparent"
                )}
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: project.color }}
                >
                  <Folder className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div
                    className={cn(
                      selectedProjectId === project.id
                        ? "text-blue-900"
                        : "text-gray-900"
                    )}
                  >
                    {project.name}
                  </div>
                  <p className="text-xs text-gray-500 truncate">
                    {project.description}
                  </p>
                </div>
              </button>
              {isAdminMode && onDeleteProject && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm(`"${project.name}" 프로젝트를 삭제하시겠습니까?`)) {
                      onDeleteProject(project.id);
                    }
                  }}
                  className="absolute top-2 right-2 p-2 rounded-md bg-white shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-50 hover:text-red-600"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
