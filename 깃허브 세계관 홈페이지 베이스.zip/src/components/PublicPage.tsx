import { useState, useMemo } from "react";
import { WorldCard } from "./WorldCard";
import { WorldDetailDialog } from "./WorldDetailDialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Search, Sparkles, BookOpen } from "lucide-react";
import type { Project, WorldItem } from "../App";

interface PublicPageProps {
  projects: Project[];
  worldItems: WorldItem[];
}

export function PublicPage({ projects, worldItems }: PublicPageProps) {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(
    projects[0]?.id || null
  );
  const [selectedItem, setSelectedItem] = useState<WorldItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("전체");

  const categories = ["전체", "캐릭터", "장소", "아이템"];

  const currentProject = projects.find((p) => p.id === selectedProjectId);

  const filteredData = useMemo(() => {
    let filtered = worldItems.filter(
      (item) => item.projectId === selectedProjectId
    );

    if (activeCategory !== "전체") {
      filtered = filtered.filter((item) => item.category === activeCategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.tags.some((tag) => tag.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [worldItems, selectedProjectId, activeCategory, searchQuery]);

  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="w-10 h-10 text-blue-600" />
            <div>
              <h1 className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                세계관 라이브러리
              </h1>
              <p className="text-gray-600">
                다양한 세계관과 캐릭터를 탐험해보세요
              </p>
            </div>
          </div>

          {/* Project Selector */}
          {projects.length > 0 && (
            <div className="flex gap-3 flex-wrap">
              {projects.map((project) => (
                <button
                  key={project.id}
                  onClick={() => setSelectedProjectId(project.id)}
                  className={`px-6 py-3 rounded-xl transition-all ${
                    selectedProjectId === project.id
                      ? "shadow-lg scale-105"
                      : "bg-white hover:shadow-md"
                  }`}
                  style={{
                    backgroundColor:
                      selectedProjectId === project.id
                        ? project.color
                        : undefined,
                    color:
                      selectedProjectId === project.id ? "white" : undefined,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    <div className="text-left">
                      <div className="font-medium">{project.name}</div>
                      <div
                        className={`text-xs ${
                          selectedProjectId === project.id
                            ? "text-white/80"
                            : "text-gray-500"
                        }`}
                      >
                        {project.description}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {selectedProjectId && currentProject ? (
          <>
            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  placeholder="제목, 설명, 태그로 검색..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white"
                />
              </div>
            </div>

            {/* Category Tabs */}
            <Tabs
              value={activeCategory}
              onValueChange={setActiveCategory}
              className="mb-8"
            >
              <TabsList className="bg-white">
                {categories.map((category) => (
                  <TabsTrigger key={category} value={category}>
                    {category}
                  </TabsTrigger>
                ))}
              </TabsList>

              {categories.map((category) => (
                <TabsContent key={category} value={category} className="mt-6">
                  {filteredData.length === 0 ? (
                    <div className="text-center py-16">
                      <p className="text-gray-500">
                        {searchQuery
                          ? "검색 결과가 없습니다"
                          : "아직 추가된 항목이 없습니다"}
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {filteredData.map((item) => (
                        <WorldCard
                          key={item.id}
                          {...item}
                          onClick={() => setSelectedItem(item)}
                        />
                      ))}
                    </div>
                  )}
                </TabsContent>
              ))}
            </Tabs>
          </>
        ) : (
          <div className="flex items-center justify-center h-full min-h-[50vh]">
            <div className="text-center">
              <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h2 className="text-gray-400 mb-2">프로젝트가 없습니다</h2>
              <p className="text-gray-400 text-sm">
                관리 모드에서 프로젝트를 만들어보세요
              </p>
            </div>
          </div>
        )}

        {/* Detail Dialog */}
        <WorldDetailDialog
          item={selectedItem}
          open={!!selectedItem}
          onOpenChange={(open) => !open && setSelectedItem(null)}
        />
      </div>
    </div>
  );
}
