import { useState, useMemo } from "react";
import { WorldCard } from "./WorldCard";
import { WorldDetailDialog } from "./WorldDetailDialog";
import { ProjectSidebar } from "./ProjectSidebar";
import { AddProjectDialog } from "./AddProjectDialog";
import { AddItemDialog } from "./AddItemDialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Search, Sparkles, Plus } from "lucide-react";
import type { Project, WorldItem } from "../App";

interface AdminPageProps {
  projects: Project[];
  setProjects: (projects: Project[]) => void;
  worldItems: WorldItem[];
  setWorldItems: (items: WorldItem[]) => void;
}

export function AdminPage({
  projects,
  setProjects,
  worldItems,
  setWorldItems,
}: AdminPageProps) {
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(
    projects[0]?.id || null
  );
  const [selectedItem, setSelectedItem] = useState<WorldItem | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("전체");
  const [isAddProjectDialogOpen, setIsAddProjectDialogOpen] = useState(false);
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = useState(false);

  const categories = ["전체", "캐릭터", "장소", "아이템"];

  const currentProject = projects.find((p) => p.id === selectedProjectId);

  const filteredData = useMemo(() => {
    let filtered = worldItems.filter(
      (item) => item.projectId === selectedProjectId
    );

    if (activeCategory !== "전체") {
      filtered = filtered.filter((item) => item.category === activeCategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (item) =>
          item.title.toLowerCase().includes(query) ||
          item.description.toLowerCase().includes(query) ||
          item.tags.some((tag) => tag.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [worldItems, selectedProjectId, activeCategory, searchQuery]);

  const handleAddProject = (projectData: {
    name: string;
    description: string;
    color: string;
  }) => {
    const newProject: Project = {
      id: Date.now().toString(),
      ...projectData,
    };
    setProjects([...projects, newProject]);
    setSelectedProjectId(newProject.id);
  };

  const handleAddItem = (itemData: {
    title: string;
    category: string;
    description: string;
    image: string;
    tags: string[];
    detailedDescription: string;
    specifications: { label: string; value: string }[];
  }) => {
    if (!selectedProjectId) return;

    const newItem: WorldItem = {
      id: Date.now().toString(),
      projectId: selectedProjectId,
      ...itemData,
    };
    setWorldItems([...worldItems, newItem]);
  };

  const handleDeleteProject = (projectId: string) => {
    setProjects(projects.filter((p) => p.id !== projectId));
    setWorldItems(worldItems.filter((item) => item.projectId !== projectId));
    if (selectedProjectId === projectId) {
      setSelectedProjectId(projects[0]?.id || null);
    }
  };

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <ProjectSidebar
        projects={projects}
        selectedProjectId={selectedProjectId}
        onSelectProject={setSelectedProjectId}
        onAddProject={() => setIsAddProjectDialogOpen(true)}
        onDeleteProject={handleDeleteProject}
        isAdminMode={true}
      />

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          {selectedProjectId && currentProject ? (
            <>
              {/* Header */}
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: currentProject.color }}
                    >
                      <Sparkles className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h1 className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        {currentProject.name}
                      </h1>
                      {currentProject.description && (
                        <p className="text-gray-600">
                          {currentProject.description}
                        </p>
                      )}
                    </div>
                  </div>
                  <Button
                    onClick={() => setIsAddItemDialogOpen(true)}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    아이템 추가
                  </Button>
                </div>
              </div>

              {/* Search */}
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="제목, 설명, 태그로 검색..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 bg-white"
                  />
                </div>
              </div>

              {/* Category Tabs */}
              <Tabs
                value={activeCategory}
                onValueChange={setActiveCategory}
                className="mb-8"
              >
                <TabsList className="bg-white">
                  {categories.map((category) => (
                    <TabsTrigger key={category} value={category}>
                      {category}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {categories.map((category) => (
                  <TabsContent key={category} value={category} className="mt-6">
                    {filteredData.length === 0 ? (
                      <div className="text-center py-16">
                        <p className="text-gray-500">
                          {searchQuery
                            ? "검색 결과가 없습니다"
                            : "아직 추가된 항목이 없습니다"}
                        </p>
                        <Button
                          onClick={() => setIsAddItemDialogOpen(true)}
                          variant="outline"
                          className="mt-4 gap-2"
                        >
                          <Plus className="w-4 h-4" />
                          첫 번째 아이템 추가하기
                        </Button>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredData.map((item) => (
                          <WorldCard
                            key={item.id}
                            {...item}
                            onClick={() => setSelectedItem(item)}
                          />
                        ))}
                      </div>
                    )}
                  </TabsContent>
                ))}
              </Tabs>
            </>
          ) : (
            <div className="flex items-center justify-center h-full min-h-[60vh]">
              <div className="text-center">
                <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h2 className="text-gray-400 mb-2">프로젝트를 선택하세요</h2>
                <p className="text-gray-400 text-sm">
                  왼쪽에서 프로젝트를 선택하거나 새로 만들어보세요
                </p>
              </div>
            </div>
          )}

          {/* Detail Dialog */}
          <WorldDetailDialog
            item={selectedItem}
            open={!!selectedItem}
            onOpenChange={(open) => !open && setSelectedItem(null)}
          />
        </div>
      </div>

      {/* Add Project Dialog */}
      <AddProjectDialog
        open={isAddProjectDialogOpen}
        onOpenChange={setIsAddProjectDialogOpen}
        onAddProject={handleAddProject}
      />

      {/* Add Item Dialog */}
      <AddItemDialog
        open={isAddItemDialogOpen}
        onOpenChange={setIsAddItemDialogOpen}
        onAddItem={handleAddItem}
      />
    </div>
  );
}
